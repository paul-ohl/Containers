To build the examples

for gcc:
make clean all test gcov

for MS Studio:
The workspace files may be out of date.